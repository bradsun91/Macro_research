# Macro_research

Hey guys:

Greetings here!
